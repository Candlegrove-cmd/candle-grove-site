export const metadata = {
  title: "Candle Grove Home Care",
  description: "Compassionate non-medical home care website package.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
