import React from "react";

const siteConfig = {
  companyName: "Candle Grove Home Care",
  tagline: "Where Care Feels Like Home",
  phoneDisplay: "(216) 555-0100",
  phoneHref: "tel:+12165550100",
  email: "info@candlegrovehomecare.com",
  referralEmail: "referrals@candlegrovehomecare.com",
  careersEmail: "careers@candlegrovehomecare.com",
  serviceArea: "Greater Cleveland, Ohio",
  hours: "Mon–Fri 9:00–5:00",
  brochureUrl: "#",
  clientFormAction: "https://formspree.io/f/your-client-form-id",
  referralFormAction: "https://formspree.io/f/your-referral-form-id",
  caregiverFormAction: "https://formspree.io/f/your-caregiver-form-id",
  primaryDomain: "www.candlegrovehomecare.com",
};

const services = [
  ["Personal Care Assistance", "Support with bathing, grooming, dressing, toileting, and mobility while preserving dignity and comfort."],
  ["Companion Care", "Warm conversation, social engagement, supervision, and encouragement to reduce isolation at home."],
  ["Respite Care", "Short-term relief for family caregivers who need time to rest, work, or manage personal responsibilities."],
  ["Meal Preparation", "Help with meal planning, food prep, and mealtime routines tailored to client preferences and schedules."],
  ["Medication Reminders", "Friendly reminders that help clients stay on track with their prescribed medication routine."],
  ["Light Housekeeping", "Assistance with laundry, dishes, tidying, and routine household tasks that support a safe home environment."],
];

const audiences = [
  ["Families", "Clear communication, flexible support, and dependable caregivers for loved ones who need help at home."],
  ["Hospitals & Discharge Teams", "A professional referral option for patients who need non-medical support after discharge."],
  ["Social Workers & Case Managers", "Responsive coordination and a trusted home care partner for community-based support."],
];

const steps = [
  ["01", "Schedule a consultation", "We learn about the client’s needs, schedule, goals, and preferred level of support."],
  ["02", "Create a care plan", "We build a personalized care approach based on routines, comfort, and daily assistance needs."],
  ["03", "Begin services", "Care starts with a dependable, compassionate plan designed to support safety and peace of mind."],
];

const faqs = [
  ["What type of home care do you provide?", "Candle Grove Home Care provides non-medical home care, including personal care, companionship, respite care, meal preparation, medication reminders, and light housekeeping."],
  ["Who can request services?", "Clients, family members, hospital staff, social workers, case managers, and other referral partners can contact us to discuss care."],
  ["Do you offer customized care plans?", "Yes. We tailor each care plan to the client’s routine, preferences, and level of support needed."],
  ["How do I get started?", "Use the contact form, call the office, or submit a referral request. We will follow up to discuss next steps."],
];

const testimonials = [
  ["Family Member", "Candle Grove brought consistency and peace of mind during a stressful time. The care felt thoughtful and respectful."],
  ["Referral Partner", "Professional communication, reliable follow-up, and a caring approach that families appreciate."],
  ["Client Family", "The intake process felt simple and supportive. We felt heard from the first conversation."],
];

function sectionTitle(kicker, title, text) {
  return (
    <div style={{maxWidth: 760}}>
      <div style={{color: "#0369a1", fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase"}}>{kicker}</div>
      <h2 style={{fontSize: 34, margin: "12px 0 0", lineHeight: 1.15}}>{title}</h2>
      {text ? <p style={{fontSize: 18, color: "#475569", lineHeight: 1.7, marginTop: 16}}>{text}</p> : null}
    </div>
  );
}

export default function Page() {
  const year = new Date().getFullYear();
  const s = siteConfig;

  return (
    <main>
      <header style={{position: "sticky", top: 0, zIndex: 20, background: "rgba(255,255,255,.95)", borderBottom: "1px solid #e2e8f0", backdropFilter: "blur(8px)"}}>
        <div style={styles.wrapRow}>
          <div>
            <div style={{fontWeight: 800, fontSize: 24, color: "#075985"}}>{s.companyName}</div>
            <div style={{fontSize: 14, color: "#64748b"}}>{s.tagline}</div>
          </div>
          <nav style={styles.nav}>
            <a href="#services">Services</a>
            <a href="#referrals">Referrals</a>
            <a href="#careers">Careers</a>
            <a href="#faq">FAQ</a>
            <a href="#contact">Contact</a>
          </nav>
          <a href="#contact" style={styles.ctaPrimary}>Get Started</a>
        </div>
      </header>

      <section style={styles.hero}>
        <div style={styles.wrapGrid}>
          <div>
            <div style={styles.badge}>Plug-and-Play Home Care Website</div>
            <h1 style={{fontSize: 56, lineHeight: 1.05, margin: "0 0 18px"}}>Compassionate home care support families can trust.</h1>
            <p style={{fontSize: 20, lineHeight: 1.7, color: "#e0f2fe", maxWidth: 650}}>
              {s.companyName} helps seniors and adults remain comfortable at home with dependable non-medical support, responsive communication, and care built around dignity.
            </p>
            <div style={{display: "flex", flexWrap: "wrap", gap: 14, marginTop: 28}}>
              <a href="#contact" style={styles.ctaWhite}>Request Care</a>
              <a href="#careers" style={styles.ctaGhost}>Apply as a Caregiver</a>
            </div>
            <div style={{display: "flex", flexWrap: "wrap", gap: 10, marginTop: 24}}>
              {["Client-centered care plans", "Dependable scheduling", "Compassionate caregivers", "Support for families and referral partners"].map((item) => (
                <div key={item} style={styles.pill}>{item}</div>
              ))}
            </div>
          </div>

          <div style={styles.card}>
            <div style={{fontSize: 13, color: "#0369a1", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase"}}>Quick Contact</div>
            <h2 style={{marginTop: 10, fontSize: 28}}>Request care information</h2>
            <p style={{color: "#475569", lineHeight: 1.7}}>Replace the placeholders below with your real details and your form will be ready to receive leads.</p>
            <form action={s.clientFormAction} method="POST" style={styles.form}>
              <input name="fullName" placeholder="Full Name" style={styles.input} />
              <input name="phone" placeholder="Best Contact Number" style={styles.input} />
              <input name="email" type="email" placeholder="Email Address" style={styles.input} />
              <input name="details" placeholder="Client Name" style={styles.input} />
              <textarea name="message" placeholder="Tell us how we can help" style={styles.textarea} />
              <button type="submit" style={styles.submit}>Submit</button>
            </form>
          </div>
        </div>
      </section>

      <section style={styles.statsWrap}>
        <div style={styles.stats}>
          <div><div style={styles.statLabel}>Phone</div><a href={s.phoneHref} style={styles.statValue}>{s.phoneDisplay}</a></div>
          <div><div style={styles.statLabel}>Email</div><a href={`mailto:${s.email}`} style={styles.statValue}>{s.email}</a></div>
          <div><div style={styles.statLabel}>Service Area</div><div style={styles.statValue}>{s.serviceArea}</div></div>
          <div><div style={styles.statLabel}>Hours</div><div style={styles.statValue}>{s.hours}</div></div>
        </div>
      </section>

      <section id="services" style={styles.section}>
        {sectionTitle("Our Services", "Everyday support that helps clients stay safely at home", "Our services are designed for families who want reliable non-medical support with compassion, consistency, and professionalism.")}
        <div style={styles.grid3}>
          {services.map(([title, text]) => (
            <div key={title} style={styles.box}>
              <div style={styles.iconPlaceholder}></div>
              <h3 style={styles.boxTitle}>{title}</h3>
              <p style={styles.boxText}>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section style={{...styles.section, background: "#fff"}}>
        <div style={styles.twoCol}>
          <div style={styles.aboutCard}>
            <div style={{fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "#cffafe"}}>About Candle Grove</div>
            <h2 style={{fontSize: 34, marginTop: 12}}>Care that feels personal</h2>
            <p style={styles.aboutText}>Candle Grove Home Care is built around dignity, trust, and responsive support. We help clients remain comfortable at home while giving families confidence that their loved ones are receiving thoughtful care.</p>
            <p style={styles.aboutText}>This site is structured for clients, referral sources, and future caregivers so your agency can launch with a professional online presence from day one.</p>
          </div>
          <div style={{display: "grid", gap: 16}}>
            <div style={styles.infoBox}>
              <h3 style={styles.boxTitle}>Mission</h3>
              <p style={styles.boxText}>To provide dependable, compassionate home care services that help clients live with comfort, dignity, and independence in the place they know best—home.</p>
            </div>
            <div style={styles.infoBox}>
              <h3 style={styles.boxTitle}>Who We Support</h3>
              <p style={styles.boxText}>Seniors, adults recovering at home, family caregivers, discharge planners, social workers, and community referral partners.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="referrals" style={styles.section}>
        {sectionTitle("Referral Partners", "A professional referral page for hospitals and social workers", "Created to help discharge teams, case managers, and social workers quickly understand who you serve and how to send referrals.")}
        <div style={styles.grid3}>
          {audiences.map(([title, text]) => (
            <div key={title} style={styles.softBox}>
              <h3 style={styles.boxTitle}>{title}</h3>
              <p style={styles.boxText}>{text}</p>
            </div>
          ))}
        </div>
        <div style={styles.outlineCard}>
          <h3 style={{fontSize: 28, marginTop: 0}}>Referral-ready highlights</h3>
          <div style={styles.grid2}>
            {["Fast intake response", "Clear communication with families", "Flexible non-medical support options", "Professional presentation for community partners"].map((item) => (
              <div key={item} style={styles.highlightItem}>{item}</div>
            ))}
          </div>
        </div>
      </section>

      <section style={{...styles.section, background: "#fff"}}>
        {sectionTitle("How It Works", "A simple intake process for families and partners")}
        <div style={styles.grid3}>
          {steps.map(([num, title, text]) => (
            <div key={num} style={styles.softBox}>
              <div style={{fontSize: 40, fontWeight: 800, color: "#075985"}}>{num}</div>
              <h3 style={styles.boxTitle}>{title}</h3>
              <p style={styles.boxText}>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="careers" style={styles.section}>
        <div style={styles.twoColWide}>
          <div>
            {sectionTitle("Careers", "A caregiver application section built in", "This section is ready for future hiring. It gives your agency a professional place to welcome caregivers and collect interest from applicants.")}
            <div style={styles.grid2}>
              <div style={styles.box}>
                <h3 style={styles.boxTitle}>Why work with us</h3>
                <p style={styles.boxText}>Supportive culture, meaningful client relationships, and a mission-centered care environment.</p>
              </div>
              <div style={styles.box}>
                <h3 style={styles.boxTitle}>Who should apply</h3>
                <p style={styles.boxText}>Dependable caregivers who value compassion, professionalism, communication, and dignity in care.</p>
              </div>
            </div>
          </div>
          <div style={styles.darkCard}>
            <div style={{fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "#67e8f9"}}>Caregiver Interest Form</div>
            <p style={{color: "#cbd5e1", lineHeight: 1.7}}>Applications can submit through the form or by email at <a href={`mailto:${s.careersEmail}`} style={{textDecoration: "underline"}}>{s.careersEmail}</a>.</p>
            <form action={s.caregiverFormAction} method="POST" style={styles.form}>
              <input name="fullName" placeholder="Full Name" style={styles.darkInput} />
              <input name="phone" placeholder="Phone Number" style={styles.darkInput} />
              <input name="email" type="email" placeholder="Email Address" style={styles.darkInput} />
              <input name="location" placeholder="City / Service Area" style={styles.darkInput} />
              <textarea name="experience" placeholder="Tell us about your caregiving background" style={styles.darkTextarea} />
              <button type="submit" style={styles.submitAlt}>Apply Now</button>
            </form>
          </div>
        </div>
      </section>

      <section style={{...styles.section, background: "#fff"}}>
        {sectionTitle("Downloadable Brochure", "A brochure section is already built into the site layout", "Add your PDF brochure link here so families, hospitals, and social workers can download a one-page overview of your services.")}
        <div style={styles.outlineSolid}>
          <div>
            <h3 style={{fontSize: 28, marginBottom: 8}}>Agency brochure</h3>
            <p style={{color: "#475569", lineHeight: 1.7}}>Replace this sample button with your real brochure file or hosted PDF link.</p>
          </div>
          <a href={s.brochureUrl} target="_blank" rel="noreferrer" style={styles.ctaPrimary}>Download Brochure</a>
        </div>
      </section>

      <section style={styles.section}>
        {sectionTitle("Testimonials", "Built to inspire trust")}
        <div style={styles.grid3}>
          {testimonials.map(([name, quote]) => (
            <div key={name} style={styles.box}>
              <p style={styles.boxText}>“{quote}”</p>
              <div style={{fontWeight: 700, marginTop: 24}}>{name}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="faq" style={{...styles.section, background: "#fff"}}>
        {sectionTitle("FAQ", "Answers to common questions")}
        <div style={{display: "grid", gap: 16}}>
          {faqs.map(([q, a]) => (
            <div key={q} style={styles.infoBox}>
              <h3 style={styles.boxTitle}>{q}</h3>
              <p style={styles.boxText}>{a}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" style={styles.contactSection}>
        <div style={styles.twoCol}>
          <div>
            <div style={{fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "#67e8f9"}}>Contact Us</div>
            <h2 style={{fontSize: 40, lineHeight: 1.1, margin: "10px 0 0"}}>Ready to launch this agency site live?</h2>
            <p style={{color: "#cbd5e1", lineHeight: 1.8, maxWidth: 650}}>Replace the sample contact details, connect your form handler, add your brochure link, point your domain to your host, and this site is ready for publishing.</p>
            <div style={{marginTop: 28, color: "#e2e8f0", lineHeight: 2}}>
              <div><strong>Phone:</strong> {s.phoneDisplay}</div>
              <div><strong>Email:</strong> {s.email}</div>
              <div><strong>Service Area:</strong> {s.serviceArea}</div>
              <div><strong>Referral Email:</strong> {s.referralEmail}</div>
            </div>
          </div>
          <div style={styles.card}>
            <h3 style={{fontSize: 28, marginTop: 0}}>Launch checklist</h3>
            <div style={{display: "grid", gap: 12}}>
              {[
                "Replace sample contact info with your real agency details",
                "Connect forms to email, CRM, or lead capture",
                "Add caregiver application workflow",
                "Upload brochure PDF and final logo assets",
                "Point your domain DNS to your hosting platform"
              ].map((item) => (
                <div key={item} style={styles.checkItem}>{item}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer style={styles.footer}>
        <div style={styles.wrapRow}>
          <div>
            <div style={{fontWeight: 700, color: "#334155"}}>{s.companyName}</div>
            <div>{s.tagline}</div>
          </div>
          <div>© {year} {s.companyName}. All rights reserved. • {s.primaryDomain}</div>
        </div>
      </footer>
    </main>
  );
}

const styles = {
  wrapRow: {maxWidth: 1200, margin: "0 auto", padding: "18px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap"},
  nav: {display: "flex", gap: 20, color: "#334155", fontWeight: 600, flexWrap: "wrap"},
  hero: {background: "linear-gradient(135deg, #082f49 0%, #075985 55%, #0e7490 100%)", color: "white", padding: "70px 24px"},
  wrapGrid: {maxWidth: 1200, margin: "0 auto", display: "grid", gap: 32, gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", alignItems: "center"},
  badge: {display: "inline-block", padding: "8px 12px", borderRadius: 999, background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.2)", fontSize: 14, marginBottom: 18},
  ctaPrimary: {background: "#0369a1", color: "white", padding: "13px 18px", borderRadius: 16, fontWeight: 700, display: "inline-block"},
  ctaWhite: {background: "white", color: "#075985", padding: "13px 18px", borderRadius: 16, fontWeight: 700, display: "inline-block"},
  ctaGhost: {border: "1px solid rgba(255,255,255,.35)", background: "rgba(255,255,255,.08)", color: "white", padding: "13px 18px", borderRadius: 16, fontWeight: 700, display: "inline-block"},
  pill: {padding: "10px 14px", borderRadius: 999, background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.18)", fontSize: 14},
  card: {background: "white", color: "#0f172a", borderRadius: 28, padding: 28, boxShadow: "0 20px 50px rgba(0,0,0,.18)"},
  darkCard: {background: "#0f172a", color: "white", borderRadius: 28, padding: 28, boxShadow: "0 20px 50px rgba(0,0,0,.18)"},
  form: {display: "grid", gap: 14, marginTop: 18},
  input: {padding: "14px 16px", borderRadius: 16, border: "1px solid #cbd5e1", fontSize: 16, outline: "none"},
  textarea: {minHeight: 120, padding: "14px 16px", borderRadius: 16, border: "1px solid #cbd5e1", fontSize: 16, outline: "none"},
  darkInput: {padding: "14px 16px", borderRadius: 16, border: "1px solid #334155", background: "#1e293b", color: "white", fontSize: 16, outline: "none"},
  darkTextarea: {minHeight: 120, padding: "14px 16px", borderRadius: 16, border: "1px solid #334155", background: "#1e293b", color: "white", fontSize: 16, outline: "none"},
  submit: {background: "#0369a1", color: "white", border: "none", borderRadius: 16, padding: "14px 18px", fontWeight: 700, fontSize: 16, cursor: "pointer"},
  submitAlt: {background: "#67e8f9", color: "#0f172a", border: "none", borderRadius: 16, padding: "14px 18px", fontWeight: 700, fontSize: 16, cursor: "pointer"},
  statsWrap: {padding: "0 24px", marginTop: -24},
  stats: {maxWidth: 1200, margin: "0 auto", background: "white", borderRadius: 28, padding: 24, display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", boxShadow: "0 8px 28px rgba(15,23,42,.08)"},
  statLabel: {fontSize: 13, color: "#0369a1", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase"},
  statValue: {fontSize: 22, fontWeight: 700, display: "block", marginTop: 8},
  section: {maxWidth: 1200, margin: "0 auto", padding: "80px 24px"},
  grid3: {display: "grid", gap: 24, gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", marginTop: 34},
  grid2: {display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))"},
  twoCol: {display: "grid", gap: 28, gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", alignItems: "start"},
  twoColWide: {display: "grid", gap: 28, gridTemplateColumns: "1.2fr .8fr"},
  box: {background: "white", border: "1px solid #e2e8f0", borderRadius: 28, padding: 24, boxShadow: "0 4px 18px rgba(15,23,42,.04)"},
  softBox: {background: "#f0f9ff", borderRadius: 28, padding: 24},
  infoBox: {background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 24, padding: 24},
  outlineCard: {marginTop: 28, border: "1px dashed #7dd3fc", background: "white", borderRadius: 28, padding: 28},
  outlineSolid: {marginTop: 28, border: "1px solid #e2e8f0", background: "#f8fafc", borderRadius: 28, padding: 28, display: "flex", justifyContent: "space-between", gap: 20, alignItems: "center", flexWrap: "wrap"},
  highlightItem: {background: "#f8fafc", borderRadius: 18, padding: 18},
  iconPlaceholder: {height: 48, width: 48, borderRadius: 18, background: "#e0f2fe", marginBottom: 14},
  boxTitle: {fontSize: 22, margin: "0 0 10px"},
  boxText: {fontSize: 16, lineHeight: 1.8, color: "#475569"},
  aboutCard: {background: "linear-gradient(135deg, #0369a1 0%, #0e7490 100%)", color: "white", borderRadius: 32, padding: 30, boxShadow: "0 16px 40px rgba(2,132,199,.18)"},
  aboutText: {lineHeight: 1.8, color: "#e0f2fe"},
  contactSection: {background: "#0f172a", color: "white", padding: "80px 24px", marginTop: 24},
  checkItem: {background: "#f8fafc", borderRadius: 18, padding: 16, color: "#334155"},
  footer: {background: "white", borderTop: "1px solid #e2e8f0", color: "#64748b"}
};
